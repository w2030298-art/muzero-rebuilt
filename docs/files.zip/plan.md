# 开发计划：RL-MEC Benchmark 架构优化 + VSCode 调试面板增强

## 元信息
- 项目：paper2-main (RL-MEC Benchmark)
- 技术栈：Python 3.10+ / PyTorch / Gymnasium / VSCode
- 总模块数：7
- 预计步骤总数：38
- 建议开发顺序：模块1 → 模块2 → 模块3 → 模块4 → 模块5 → 模块6 → 模块7（按 "快速见效 → 基础设施 → 核心重构 → 扫尾" 排列）

---

## 模块 1：VSCode 调试面板全面优化

### 概述
- 职责：将 27 个配置项压缩到 ~12 个，用 `inputs` 动态选择替代逐算法硬编码，补齐缺失的 tasks.json / settings.json / extensions.json
- 前置依赖：无
- 预计步骤数：7

### Step 1：创建 `.vscode/settings.json` 统一 PYTHONPATH
- 操作：创建 `.vscode/settings.json`
  - 设置 `python.analysis.extraPaths`：`["${workspaceFolder}", "${workspaceFolder}/src", "${workspaceFolder}/scripts", "${workspaceFolder}/rl_algorithms"]`
  - 设置 `python.defaultInterpreterPath`：`"${workspaceFolder}/.venv/bin/python"` (兼容 Linux/WSL)
  - 设置 `python.testing.pytestEnabled`：`true`
  - 设置 `python.testing.pytestArgs`：`["tests"]`
- 验证：VSCode 打开项目后，Pylance 不再报 import 红线

### Step 2：重写 `.vscode/launch.json` — 定义 inputs 变量
- 操作：在 launch.json 底部添加 `inputs` 数组
  - `algorithmName`：类型 `pickString`，选项为全部 17 个算法名
  - `runId`：类型 `pickString`，选项为 `["paper2_full_17_vscode", "vscode_quick"]`
  - `presetName`：类型 `pickString`，选项为 `["quick", "full17"]`
- 关键代码指引：
  ```json
  "inputs": [
    {
      "id": "algorithmName",
      "type": "pickString",
      "description": "选择算法",
      "options": ["GRPO","PPO","SAC","DDQN","DDPG","TD3","A3C","TRPO","SimPO","MAPPO","QMIX","COMA","IPPO","VDN","MADDPG","IQL","MATD3"]
    },
    {
      "id": "runId",
      "type": "pickString",
      "description": "选择实验 Run ID",
      "options": ["paper2_full_17_vscode", "vscode_quick"]
    }
  ]
  ```
- 验证：JSON 语法正确，`inputs` 块存在

### Step 3：重写 `.vscode/launch.json` — 精简 configurations 到 12 个
- 操作：替换整个 `configurations` 数组，保留以下 12 个配置：
  1. `🧪 Quick Start/Resume` — args: `["start", "--preset", "quick"]`
  2. `🧪 Quick Fresh Clean Run` — args: `["start", "--preset", "quick", "--fresh"]`
  3. `🧪 Quick Status` — args: `["status", "--run-id", "vscode_quick"]`
  4. `🧪 Quick Stop` — args: `["stop", "--run-id", "vscode_quick"]`
  5. `🏁 Full 17 Start/Resume` — args: `["start", "--preset", "full17"]`
  6. `📊 Full 17 Status` — args: `["status", "--run-id", "paper2_full_17_vscode"]`
  7. `⏹ Full 17 Stop` — args: `["stop", "--run-id", "paper2_full_17_vscode"]`
  8. `📦 Export Results` — args: `["export", "--run-id", "${input:runId}", "--output", "results/benchmark_${input:runId}.json"]`
  9. `♻️ Reset Algorithm` — args: `["reset", "--run-id", "${input:runId}", "--algorithm", "${input:algorithmName}"]`
  10. `📋 List All Experiments` — args: `["list"]`
  11. `🧱 Rebuild Index` — args: `["rebuild-index"]`
  12. `🏁 Benchmark Direct All 17` — program: `benchmark.py`, args: `["--all", "--episodes", "10", "--timesteps", "100000", "--device", "auto", "--output", "results/benchmark_direct_all_17_vscode.json"]`
- 关键要求：
  - 所有配置共用的字段（type, request, cwd, console, justMyCode）不变
  - `env.PYTHONPATH` 保留在每个配置中（VSCode `settings.json` 的 `extraPaths` 只影响语言服务器，不影响 debugpy 的运行时 PYTHONPATH）
  - 配置 1-11 的 `program` 统一为 `${workspaceFolder}/scripts/experiment_manager.py`
  - 配置 12 的 `program` 为 `${workspaceFolder}/scripts/benchmark.py`
- 验证：`python -m json.tool .vscode/launch.json` 无报错；配置总数 = 12

### Step 4：创建 `.vscode/tasks.json`
- 操作：创建任务文件，包含以下任务条目：
  - `experiment: full17 start-resume` — `python scripts/experiment_manager.py start --preset full17`
  - `experiment: full17 status` — `python scripts/experiment_manager.py status --run-id paper2_full_17_vscode`
  - `experiment: full17 stop` — `python scripts/experiment_manager.py stop --run-id paper2_full_17_vscode`
  - `experiment: full17 export` — `python scripts/experiment_manager.py export --run-id paper2_full_17_vscode --output results/benchmark_paper2_full_17_vscode.json`
  - `experiment: quick start-resume` — `python scripts/experiment_manager.py start --preset quick`
  - `experiment: quick fresh` — `python scripts/experiment_manager.py start --preset quick --fresh`
  - `experiment: quick status` — `python scripts/experiment_manager.py status --run-id vscode_quick`
  - `experiment: quick stop` — `python scripts/experiment_manager.py stop --run-id vscode_quick`
  - `experiment: list` — `python scripts/experiment_manager.py list`
  - `experiment: rebuild-index` — `python scripts/experiment_manager.py rebuild-index`
  - `benchmark: direct all17` — `python scripts/benchmark.py --all --episodes 10 --timesteps 100000 --device auto --output results/benchmark_direct_all_17_vscode.json`
  - `check-environment` — `python -c "import torch; import gymnasium; print('✅ Dependencies OK'); print(f'CUDA: {torch.cuda.is_available()}')"` ，设为 `isBackground: false`
- 关键要求：
  - 所有 task 的 `type` 为 `"process"`（非 shell，避免跨平台问题）
  - `cwd` 为 `"${workspaceFolder}"`
  - `env` 中设置与 launch.json 相同的 PYTHONPATH
  - `presentation.group` 按 `Full 17`、`Quick`、`管理`、`Benchmark` 分组
- 验证：VSCode 中 Terminal → Run Task... 能看到所有任务并分组显示

### Step 5：创建 `.vscode/extensions.json`
- 操作：创建推荐扩展文件
  ```json
  {
    "recommendations": [
      "ms-python.python",
      "ms-python.debugpy",
      "ms-python.vscode-pylance"
    ]
  }
  ```
- 验证：VSCode 打开项目时弹出扩展推荐提示

### Step 6：为 Full 17 Start/Resume 添加 preLaunchTask
- 操作：在 launch.json 的 `🏁 Full 17 Start/Resume` 和 `🧪 Quick Start/Resume` 配置中添加 `"preLaunchTask": "check-environment"`
- 关键要求：`check-environment` task 在 tasks.json 中已定义（Step 4），且不能 `isBackground: true`
- 验证：启动训练前，终端自动打印 `✅ Dependencies OK` 和 CUDA 状态

### Step 7：同步更新 VSCode 相关文档
- 操作：
  - 更新 `docs/vscode_experiment_usage.md`：
    - 修改"VSCode Tasks 入口"章节的任务列表使其与新 tasks.json 一致
    - 新增"inputs 动态选择"说明：解释 Reset Algorithm 和 Export Results 会弹出下拉框
    - 新增"环境预检"说明
  - 更新 `docs/vscode_debug_guide.md`（项目根 docs/ 下）：
    - 添加新的配置清单表格（12 个配置）
    - 标注旧文档 `docs_paper/vscode_debug_guide.md` 为过期
  - 在 `docs_paper/vscode_debug_guide.md` 顶部添加废弃声明：`> ⚠️ 本文档已过期，请参考 docs/vscode_debug_guide.md`
- 验证：文档中列出的配置名与 launch.json 中的 `name` 字段一一对应

### 验收标准
- [ ] launch.json 配置项 ≤ 12 个
- [ ] 所有 Reset 操作通过一个配置 + 下拉框完成
- [ ] tasks.json 存在且包含 12 个任务
- [ ] extensions.json 存在
- [ ] settings.json 存在且 Pylance 无 import 红线
- [ ] 文档与实际配置一致

---

## 模块 2：算法注册表与配置去重

### 概述
- 职责：将 `benchmark.py`、`train.py`、`registry.py`、`presets.py` 中分散的算法元数据统一到单一数据源
- 前置依赖：无（与模块 1 并行安全）
- 预计步骤数：5

### Step 1：扩展 `src/experiment/registry.py` 为权威数据源
- 操作：在 `AlgorithmRegistry` 中新增以下类属性/方法：
  - `ALGORITHM_CLASSES: dict[str, tuple[str, str]]` — 模块路径 + 类名映射（从 benchmark.py 迁移）
  - `ALGO_ENV_MAP: dict[str, str]` — 算法→环境 ID 映射（从 benchmark.py 迁移）
  - `ON_POLICY: set[str]` 和 `OFF_POLICY: set[str]`（从 benchmark.py 迁移）
  - `def import_agent(self, name: str) -> type` — 动态导入并返回 Agent 类
  - `def env_id_for(self, name: str) -> str` — 返回算法对应的环境 ID
- 关键要求：现有的 `SUPPORTED_ALGORITHMS`、`canonicalize()`、`build_specs()` 保持不变
- 验证：`python -c "from src.experiment.registry import AlgorithmRegistry; r = AlgorithmRegistry(); print(r.import_agent('PPO'))"` 输出 `<class 'rl_algorithms.ppo.PPOAgent'>`

### Step 2：重构 `scripts/benchmark.py` 使用 registry
- 操作：
  - 删除 benchmark.py 顶部的 `ALGORITHM_CLASSES`、`ALGO_ENV_MAP`、`ON_POLICY`、`OFF_POLICY`、`ALL_ALGOS` 常量
  - 改为 `from src.experiment.registry import AlgorithmRegistry`
  - `registry = AlgorithmRegistry()` 然后用 `registry.ALGORITHM_CLASSES`、`registry.ALGO_ENV_MAP` 等替换
  - 如果 benchmark.py 中有 Heuristic 算法（Greedy/Random/Local-only/Full-offload），保留在 benchmark.py 本地，仅迁移 RL 算法映射
- 验证：`python scripts/benchmark.py --help` 正常输出且算法列表完整

### Step 3：重构 `scripts/train.py` 使用 registry
- 操作：
  - train.py 中如果有 `ALGORITHM_CLASSES` 或类似的硬编码映射，改为从 registry 导入
  - 使用 `registry.import_agent(algo_name)` 替代手动 `importlib.import_module`
- 验证：`python scripts/train.py --config configs/algorithms/ppo.yaml --algorithm PPO --timesteps 100 --dry-run` 正常（如果有 dry-run；否则检查 import 无报错）

### Step 4：清理 `configs/default.yaml`
- 操作：
  - 检查项目中是否有任何代码引用 `configs/default.yaml`：`grep -r "default.yaml" --include="*.py"`
  - 如果无引用：在文件顶部添加注释 `# DEPRECATED: This file is not used. Per-algorithm configs are in configs/algorithms/`
  - 如果有引用：统一 `hidden_dims` → `hidden_dim`（与各算法 yaml 一致），`env.name` 更新为 `MEC-v1-game-theory`
- 验证：`grep -rn "hidden_dims" configs/` 无结果（或只在已标注废弃的 default.yaml 中）

### Step 5：添加注册表单元测试
- 操作：在 `tests/test_experiment_registry.py` 中新增：
  - `test_import_all_agents` — 遍历 17 个算法，验证 `registry.import_agent()` 返回有效类
  - `test_env_id_for_all_algorithms` — 验证每个算法都有对应的环境 ID
  - `test_on_off_policy_partition` — 验证 ON_POLICY ∪ OFF_POLICY == SUPPORTED_ALGORITHMS 且无交集
  - `test_algo_env_map_covers_all` — 验证 ALGO_ENV_MAP 覆盖所有 SUPPORTED_ALGORITHMS
- 验证：`pytest tests/test_experiment_registry.py -v` 全部通过

### 验收标准
- [ ] `benchmark.py` 不再包含 `ALGORITHM_CLASSES` 等硬编码常量
- [ ] `registry.py` 是算法元数据的唯一来源
- [ ] 新增测试全部通过
- [ ] `configs/default.yaml` 已标注废弃或已修正

---

## 模块 3：`game_theory_env.py` God File 拆分

### 概述
- 职责：将 1660 行 14 类的单文件拆分为 8 个子模块，保持外部接口不变
- 前置依赖：无（纯内部重构）
- 预计步骤数：8

### Step 1：创建子模块文件并迁移 `OptimalPricingMechanism`
- 操作：
  - 创建 `src/environments/mec_v3/pricing.py`
  - 将 `OptimalPricingMechanism` 类（约 55 行）从 `game_theory_env.py` 剪切到 `pricing.py`
  - 在 `pricing.py` 顶部添加必要 import（`numpy`）
  - 在 `game_theory_env.py` 中改为 `from .pricing import OptimalPricingMechanism`
- 验证：`python -c "from src.environments.mec_v3.pricing import OptimalPricingMechanism; print('OK')"`

### Step 2：迁移 `BilevelGameSolver`
- 操作：
  - 创建 `src/environments/mec_v3/bilevel_solver.py`
  - 将 `BilevelGameSolver` 类（约 116 行）迁移
  - `BilevelGameSolver.__init__` 接收 `OptimalPricingMechanism` 实例，在 `bilevel_solver.py` 中 `from .pricing import OptimalPricingMechanism`
  - 在 `game_theory_env.py` 中改为 `from .bilevel_solver import BilevelGameSolver`
- 验证：`python -c "from src.environments.mec_v3.bilevel_solver import BilevelGameSolver; print('OK')"`

### Step 3：迁移 `MonteCarloShapley`
- 操作：
  - 创建 `src/environments/mec_v3/shapley.py`
  - 将 `MonteCarloShapley` 类（约 46 行）迁移
  - 在 `game_theory_env.py` 中改为 `from .shapley import MonteCarloShapley`
- 验证：`python -c "from src.environments.mec_v3.shapley import MonteCarloShapley; print('OK')"`

### Step 4：迁移物理模型（`QueueingDelayModel`, `DVFSEnergyModel`, `Channel3GPP`）
- 操作：
  - 创建 `src/environments/mec_v3/physical_models.py`
  - 将三个类（合计约 100 行）迁移到一个文件（它们彼此无依赖但概念上同属物理层模型）
  - 在 `game_theory_env.py` 中改为 `from .physical_models import QueueingDelayModel, DVFSEnergyModel, Channel3GPP`
- 验证：`python -c "from src.environments.mec_v3.physical_models import QueueingDelayModel, DVFSEnergyModel, Channel3GPP; print('OK')"`

### Step 5：迁移动作空间和约束投影（`ParameterizedActionSpace`, `ConstraintProjection`, `ProjectionResult`）
- 操作：
  - 创建 `src/environments/mec_v3/action_space.py`
  - 将三个类迁移
  - 在 `game_theory_env.py` 中改为 `from .action_space import ParameterizedActionSpace, ConstraintProjection, ProjectionResult`
- 验证：`python -c "from src.environments.mec_v3.action_space import ParameterizedActionSpace; print('OK')"`

### Step 6：迁移公平性模块（`CPNetPreferenceModel`, `EFXFairAllocation`, `EFXRepairResult`）
- 操作：
  - 创建 `src/environments/mec_v3/fairness.py`
  - 将三个类迁移（`CPNetPreferenceModel` 约 116 行，`EFXFairAllocation` 约 62 行）
  - 在 `game_theory_env.py` 中改为 `from .fairness import CPNetPreferenceModel, EFXFairAllocation, EFXRepairResult`
- 验证：`python -c "from src.environments.mec_v3.fairness import CPNetPreferenceModel, EFXFairAllocation; print('OK')"`

### Step 7：迁移 `HierarchicalReward`
- 操作：
  - 创建 `src/environments/mec_v3/reward.py`
  - 将 `HierarchicalReward` 类（约 96 行）迁移
  - 在 `game_theory_env.py` 中改为 `from .reward import HierarchicalReward`
- 验证：`python -c "from src.environments.mec_v3.reward import HierarchicalReward; print('OK')"`

### Step 8：更新 `__init__.py` 导出 + 全量测试
- 操作：
  - 更新 `src/environments/mec_v3/__init__.py`：确保所有拆分出的类都通过 `__init__` 重导出（保持向后兼容）
  - 运行完整测试套件：`pytest tests/ -v`
  - 验证 graphify-out 或任何其他文件中引用这些类的 import 路径仍然有效
- 特别注意：
  - `game_theory_env.py` 开头的 `sys.path.insert` 逻辑需要在各子模块中检查是否需要保留
  - 各子模块之间如果有循环依赖，用延迟 import 或参数传递解决
- 验证：
  - `pytest tests/test_mec_envs.py -v` 通过
  - `pytest tests/test_game_theory_fusion.py -v` 通过
  - `pytest tests/test_algorithms_on_envs.py -v` 通过
  - `game_theory_env.py` 行数 ≤ 400 行

### 验收标准
- [ ] `game_theory_env.py` 仅包含 `GameTheoryMECEnv` 类，行数 ≤ 400
- [ ] 8 个新子模块各自可独立导入
- [ ] 所有现有测试通过
- [ ] 外部 API（环境创建、gym 注册）不变

---

## 模块 4：Trainer 重复代码抽取

### 概述
- 职责：将 on_policy_trainer 和 off_policy_trainer 中重复的 rollout 辅助逻辑提取到 BaseTrainer
- 前置依赖：无
- 预计步骤数：4

### Step 1：识别和标记重复代码段
- 操作：
  - 对比 `on_policy_trainer.py` 和 `off_policy_trainer.py` 的 `_collect_rollout` 方法
  - 标记以下共同逻辑块：
    - 多智能体观测展开：`if self._is_multi_agent` 的 obs 处理
    - 动作格式转换：`_is_discrete` / `_is_dict` 分支
    - info 字典中 game theory 信息提取：`eq_actions`、`shapley_values`、`reward_terms`、`game_hint_vectors`
    - `_reward_terms_to_array` 辅助函数（两个文件中完全相同）
    - `__init__` 中的 `_is_discrete`、`_is_dict`、`_is_multi_agent`、`_ma_mode` 检测逻辑
  - 在代码中以注释标记 `# EXTRACT: shared logic`
- 验证：两个文件中标记的代码块在语义上等价

### Step 2：在 `BaseTrainer` 中新增共享工具方法
- 操作：在 `base_trainer.py` 中添加：
  - `_detect_env_properties(self)` — 检测 `_is_discrete`、`_is_dict`、`_is_multi_agent`、`_ma_mode`，在 `__init__` 末尾调用
  - `_unpack_obs(self, obs)` — 处理多智能体观测展开逻辑
  - `_format_action(self, action_result, ...)` — 根据 `_is_discrete` 等属性转换动作格式
  - `_extract_game_theory_info(self, info: dict) -> dict` — 从 step info 中提取 eq_actions、shapley_values 等
  - `@staticmethod _reward_terms_to_array(terms) -> np.ndarray` — 移入 BaseTrainer
- 关键要求：
  - 新方法只做数据处理，不改变训练逻辑
  - 签名设计让 on/off policy 都能调用
- 验证：`python -c "from src.trainer.base_trainer import BaseTrainer; print(dir(BaseTrainer))"` 能看到新方法

### Step 3：重构 `OnPolicyTrainer._collect_rollout` 使用共享方法
- 操作：
  - 删除 `__init__` 中的重复检测逻辑，改用 `self._detect_env_properties()`
  - 删除 `_reward_terms_to_array` 内嵌函数，改用 `self._reward_terms_to_array`
  - 将 obs 展开逻辑替换为 `self._unpack_obs(obs)`
  - 将 game theory info 提取替换为 `self._extract_game_theory_info(info)`
- 验证：`pytest tests/test_trainers.py -v` 通过

### Step 4：重构 `OffPolicyTrainer._collect_rollout` 使用共享方法
- 操作：同 Step 3 的改法，应用到 off_policy_trainer.py
- 验证：`pytest tests/test_trainers.py -v` 通过

### 验收标准
- [ ] `on_policy_trainer.py` 和 `off_policy_trainer.py` 中无逐行重复代码
- [ ] `BaseTrainer` 新增方法有 docstring
- [ ] 所有 trainer 测试通过

---

## 模块 5：环境适配器 Gym 合规

### 概述
- 职责：让 `GameTheoryDiscreteMAEnv` 和 `GameTheoryContinuousMAEnv` 继承 `gymnasium.Env`
- 前置依赖：模块 3（文件已拆分，适配器文件更干净）
- 预计步骤数：3

### Step 1：修改 `GameTheoryDiscreteMAEnv` 继承 `gymnasium.Env`
- 操作：
  - `class GameTheoryDiscreteMAEnv(gymnasium.Env):` — 添加继承
  - 添加 `metadata = {"render_modes": ["human"]}`
  - 保留 `__getattr__` 透传但添加注释说明仅用于非标准属性（如 `queue_lengths`, `game_history`）
  - `reset()` 返回值保持 `(obs, info)` 格式
  - `step()` 返回值保持 `(obs, reward, terminated, truncated, info)` 五元组
- 特别注意：检查 `step()` 的返回值是否已经是 Gymnasium 的五元组格式；如果底层 `GameTheoryMECEnv.step()` 返回旧版四元组 `(obs, reward, done, info)`，需要在适配器中转换
- 验证：`python -c "import gymnasium; from src.environments.mec_v3.game_theory_adapters import GameTheoryDiscreteMAEnv; e = GameTheoryDiscreteMAEnv(); assert isinstance(e, gymnasium.Env); print('OK')"`

### Step 2：修改 `GameTheoryContinuousMAEnv` 继承 `gymnasium.Env`
- 操作：同 Step 1，应用到连续适配器
- 验证：`python -c "import gymnasium; from src.environments.mec_v3.game_theory_adapters import GameTheoryContinuousMAEnv; e = GameTheoryContinuousMAEnv(); assert isinstance(e, gymnasium.Env); print('OK')"`

### Step 3：验证兼容性
- 操作：
  - 运行 `pytest tests/test_mec_envs.py tests/test_algorithms_on_envs.py -v`
  - 尝试用 `gymnasium.wrappers.RecordEpisodeStatistics` 包装适配器环境，验证不报错
- 验证：所有测试通过 + wrapper 测试通过

### 验收标准
- [ ] 两个适配器都通过 `isinstance(env, gymnasium.Env)` 检查
- [ ] 可以被 gymnasium.wrappers 正常包装
- [ ] 所有现有测试不受影响

---

## 模块 6：进程管理优化

### 概述
- 职责：优化 `ProcessRunner.run_algorithm` 的轮询机制，减少无谓 CPU 唤醒
- 前置依赖：无
- 预计步骤数：3

### Step 1：替换固定 sleep(1) 为 `process.wait(timeout=N)` + 自适应间隔
- 操作：在 `src/experiment/process_runner.py` 的 `run_algorithm` 方法中，修改主循环：
  ```python
  poll_interval = 2.0  # 初始 2 秒
  max_interval = 10.0  # 最大 10 秒
  while True:
      try:
          process.wait(timeout=poll_interval)
          break  # 进程已结束
      except subprocess.TimeoutExpired:
          pass  # 还在运行

      if self.store.has_stop_request(run_id):
          # ... 中断逻辑不变
          break

      poll_interval = min(poll_interval * 1.5, max_interval)
  ```
- 关键要求：
  - stop request 检查仍然保留
  - Windows 兼容性：`process.wait(timeout=N)` 在 Windows 上也正常工作
  - 第一次检查在 2 秒后（快速响应），之后逐渐放慢到 10 秒
- 验证：`pytest tests/test_experiment_process_runner.py -v` 通过

### Step 2：添加进程启动日志
- 操作：在 `run_algorithm` 启动子进程后，使用 `logging` 输出：
  - 算法名
  - PID
  - 命令行
  - 预计训练步数
- 验证：启动实验时终端有可读的进程信息输出

### Step 3：优化 stop 响应路径
- 操作：
  - stop request 检查移到 `process.wait` 的 `TimeoutExpired` 异常处理中，确保每次 wait 超时后立即检查
  - 减少 stop 后的 graceful shutdown 超时从 30 秒到 15 秒（大多数训练脚本不需要 30 秒来保存 checkpoint）
- 特别注意：如果训练脚本在 `SIGINT` 后需要保存大 checkpoint，15 秒可能不够。可通过环境变量 `STOP_GRACE_PERIOD` 让用户自定义
- 验证：发送 stop 请求后，实际停止延迟 ≤ 轮询间隔 + 15 秒

### 验收标准
- [ ] CPU 占用在长训练期间显著降低（无高频唤醒）
- [ ] stop 响应时间 ≤ 当前轮询间隔 + grace period
- [ ] 进程启动时有明确日志
- [ ] 所有 process_runner 测试通过

---

## 模块 7：测试补全、类型检查与文档扫尾

### 概述
- 职责：补全测试覆盖、添加 mypy 配置、最终文档同步
- 前置依赖：模块 1-6 全部完成
- 预计步骤数：8

### Step 1：在 `pyproject.toml` 添加 mypy 配置
- 操作：在 `pyproject.toml` 中添加：
  ```toml
  [tool.mypy]
  python_version = "3.10"
  warn_return_any = true
  warn_unused_configs = true
  ignore_missing_imports = true

  [[tool.mypy.overrides]]
  module = ["src.experiment.*", "src.environments.mec_v3.*"]
  disallow_untyped_defs = true
  ```
- 关键要求：先只对核心模块启用严格模式，rl_algorithms 暂不覆盖（太多算法文件，逐步推进）
- 验证：`mypy src/experiment/ src/environments/mec_v3/ --config-file pyproject.toml` 无 error（可有 warning）

### Step 2：扩展 `tests/test_mec_envs.py`
- 操作：新增测试用例：
  - `test_discrete_adapter_action_space_size` — 验证离散动作空间大小 = (K+1) * 5³
  - `test_continuous_adapter_action_space_shape` — 验证连续动作空间 shape = (4,)
  - `test_discrete_encode_decode_roundtrip` — 编码→解码→再编码一致
  - `test_continuous_decode_clipping` — 超范围动作被正确裁剪
  - `test_multi_agent_obs_shape` — 多智能体观测维度正确
  - `test_env_reset_determinism` — 相同 seed 的 reset 结果一致
- 验证：`pytest tests/test_mec_envs.py -v` 新增用例全部通过

### Step 3：扩展算法集成测试
- 操作：在 `tests/test_algorithms_on_envs.py` 中：
  - 确保 17 个算法全部有对应的 smoke test（创建 agent → 1 步 select_action → 无报错）
  - 对当前缺失的算法（如 COMA、IPPO、VDN 等新增的 6 个多智能体算法）添加测试
  - 每个算法测试使用极少步数（100 步）验证训练循环无报错
- 特别注意：部分算法可能需要特定的 `num_agents` 参数
- 验证：`pytest tests/test_algorithms_on_envs.py -v` 全部通过（17 个算法 17 个测试）

### Step 4：补充拆分后子模块的单元测试
- 操作：创建 `tests/test_mec_v3_components.py`，测试模块 3 拆分后的各组件：
  - `test_optimal_pricing_solve` — 给定参数能收敛到有效价格
  - `test_bilevel_solver_converges` — 双层博弈求解器能在 max_iter 内收敛
  - `test_shapley_value_symmetry` — 对称玩家的 Shapley 值相等
  - `test_queueing_delay_monotone` — 负载越高，延迟越大
  - `test_dvfs_energy_range` — 能耗值在物理合理范围内
  - `test_hierarchical_reward_weights` — 权重之和为 1
- 验证：`pytest tests/test_mec_v3_components.py -v` 全部通过

### Step 5：添加 ruff 配置
- 操作：在 `pyproject.toml` 中添加：
  ```toml
  [tool.ruff]
  line-length = 100
  target-version = "py310"

  [tool.ruff.lint]
  select = ["E", "F", "I", "W"]
  ignore = ["E501"]  # 暂时忽略行长限制（现有代码大量超长行）
  ```
- 验证：`ruff check src/ rl_algorithms/ scripts/ tests/` 无 error（warning 可接受）

### Step 6：更新 README.md 的项目结构
- 操作：
  - 更新 README 中的项目结构树，反映 mec_v3/ 目录的新子模块
  - 添加 `.vscode/` 目录说明
  - 更新"安装"章节，提及 `mypy` 和 `ruff` 开发依赖
- 验证：README 中的目录树与实际文件系统一致

### Step 7：更新 `requirements.txt` 或 `pyproject.toml` 的开发依赖
- 操作：
  - 在 `pyproject.toml` 的 `[project.optional-dependencies]` 中添加 `dev` 组：
    ```toml
    [project.optional-dependencies]
    dev = ["mypy", "ruff", "pytest", "debugpy"]
    ```
- 验证：`pip install -e ".[dev]"` 正常安装

### Step 8：最终全量验收
- 操作：
  - `pytest tests/ -v --tb=short` — 所有测试通过
  - `ruff check src/ rl_algorithms/ scripts/ tests/` — 无 error
  - `mypy src/experiment/ src/environments/mec_v3/ --config-file pyproject.toml` — 无 error
  - 打开 VSCode 检查 launch.json、tasks.json 正常加载
  - 尝试运行 `🧪 Quick Start/Resume` 配置
- 验证：全部检查通过

### 验收标准
- [ ] mypy 对核心模块零 error
- [ ] ruff 零 error
- [ ] 测试总数 ≥ 原有测试数 + 25 个新增测试
- [ ] README 与实际一致
- [ ] 开发依赖可一键安装
