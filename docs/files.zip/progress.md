# 开发进度

## 当前状态
- 当前阶段：[模块1] Step 1
- 最后更新：2026-04-29
- 状态：待启动

## 模块进度

### 模块 1：VSCode 调试面板全面优化
- [ ] Step 1: 创建 `.vscode/settings.json` 统一 PYTHONPATH
- [ ] Step 2: 重写 `.vscode/launch.json` — 定义 inputs 变量
- [ ] Step 3: 重写 `.vscode/launch.json` — 精简 configurations 到 12 个
- [ ] Step 4: 创建 `.vscode/tasks.json`
- [ ] Step 5: 创建 `.vscode/extensions.json`
- [ ] Step 6: 为 Full 17 Start/Resume 添加 preLaunchTask
- [ ] Step 7: 同步更新 VSCode 相关文档

### 模块 2：算法注册表与配置去重
- [ ] Step 1: 扩展 `src/experiment/registry.py` 为权威数据源
- [ ] Step 2: 重构 `scripts/benchmark.py` 使用 registry
- [ ] Step 3: 重构 `scripts/train.py` 使用 registry
- [ ] Step 4: 清理 `configs/default.yaml`
- [ ] Step 5: 添加注册表单元测试

### 模块 3：`game_theory_env.py` God File 拆分
- [ ] Step 1: 迁移 `OptimalPricingMechanism` → `pricing.py`
- [ ] Step 2: 迁移 `BilevelGameSolver` → `bilevel_solver.py`
- [ ] Step 3: 迁移 `MonteCarloShapley` → `shapley.py`
- [ ] Step 4: 迁移物理模型 → `physical_models.py`
- [ ] Step 5: 迁移动作空间 → `action_space.py`
- [ ] Step 6: 迁移公平性模块 → `fairness.py`
- [ ] Step 7: 迁移 `HierarchicalReward` → `reward.py`
- [ ] Step 8: 更新 `__init__.py` 导出 + 全量测试

### 模块 4：Trainer 重复代码抽取
- [ ] Step 1: 识别和标记重复代码段
- [ ] Step 2: 在 `BaseTrainer` 中新增共享工具方法
- [ ] Step 3: 重构 `OnPolicyTrainer._collect_rollout`
- [ ] Step 4: 重构 `OffPolicyTrainer._collect_rollout`

### 模块 5：环境适配器 Gym 合规
- [ ] Step 1: 修改 `GameTheoryDiscreteMAEnv` 继承 `gymnasium.Env`
- [ ] Step 2: 修改 `GameTheoryContinuousMAEnv` 继承 `gymnasium.Env`
- [ ] Step 3: 验证兼容性

### 模块 6：进程管理优化
- [ ] Step 1: 替换固定 sleep(1) 为自适应轮询
- [ ] Step 2: 添加进程启动日志
- [ ] Step 3: 优化 stop 响应路径

### 模块 7：测试补全、类型检查与文档扫尾
- [ ] Step 1: 在 `pyproject.toml` 添加 mypy 配置
- [ ] Step 2: 扩展 `tests/test_mec_envs.py`
- [ ] Step 3: 扩展算法集成测试
- [ ] Step 4: 补充拆分后子模块的单元测试
- [ ] Step 5: 添加 ruff 配置
- [ ] Step 6: 更新 README.md 的项目结构
- [ ] Step 7: 更新 `requirements.txt` 或 `pyproject.toml` 的开发依赖
- [ ] Step 8: 最终全量验收

## 已知问题
（暂无）
